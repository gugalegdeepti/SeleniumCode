﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace DynamicTable
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://money.rediff.com/gainers/bsc/daily/groupa");
            IList<IWebElement> col = driver.FindElements(By.XPath("//*[@class='dataTable']/thead/tr/th"));
            int colSize = col.Count;

            IList<IWebElement> rows = driver.FindElements(By.XPath("//*[@class='dataTable']/tbody/tr/td[1]"));
            int rowsize = rows.Count;

            IWebElement cellrequired = driver.FindElement(By.XPath("//*[@class='dataTable']/tbody/tr[3]/td[3]"));
            string value = cellrequired.Text;
        }
    }
}
