﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrokenURL.PageActions
{
    public class GoogleImagesPage
    {
        public GoogleImagesPage()
        {
            PageFactory.InitElements(Driver.driver, this);
        }

        [FindsBy(How=How.XPath, Using= "//*[@class='S3Wjs']")]
        public IWebElement SearchByImage { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='qbtbha qbtbtxt qbclr']")]
        public IWebElement UploadAnImage { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='qbfile']")]
        public IWebElement ChooseFile { get; set; }

        //[FindsBy(How = How.CssSelector, Using = "# qbfile")]
        //public IWebElement ChooseFile { get; set; }

    }
}
