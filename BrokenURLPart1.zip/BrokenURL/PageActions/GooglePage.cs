﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace BrokenURL.PageActions
{
    public class GooglePage
    {
        public GooglePage()
        {
            PageFactory.InitElements(Driver.driver, this);
        }

        //[FindsBy(How = How.XPath, Using = "//*[@class='gb_P'][text()='Images']")]

        [FindsBy(How = How.CssSelector, Using = "#gbw > div > div > div.gb_De.gb_R.gb_ah.gb_1g > div:nth-child(2) > a")]
        public IWebElement Images { get; set; }
    }
}
