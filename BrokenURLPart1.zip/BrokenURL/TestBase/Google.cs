﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BrokenURL.PageActions;

namespace BrokenURL.TestBase
{
    public static class Google
    {
        public static void NavigateToGoogle()
        {
            string url = "http://www.google.com";

            Driver.driver.Navigate().GoToUrl(url);
        }

        public static void UploadImage()
        {
            GooglePage googlePage = new GooglePage();
            GoogleImagesPage googleImagesPage = new GoogleImagesPage();

            googlePage.Images.Click();
            googleImagesPage.SearchByImage.Click();
            googleImagesPage.UploadAnImage.Click();
            googleImagesPage.ChooseFile.SendKeys("D:\\nature.jpg");
        }


    }
}
