﻿using System;
using System.Collections.Generic;
using System.Net;
using BrokenURL.TestBase;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;

namespace BrokenURL
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void BrokenURL()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.microsoft.com/en-in/store/b/home");
            IList<IWebElement> urls = driver.FindElements(By.TagName("a"));

            HttpWebRequest re = null;

            foreach (var url in urls)
            {
                //get the url
                re = (HttpWebRequest)WebRequest.Create(url.GetAttribute("href"));
                var response = (HttpWebResponse)re.GetResponse();
                var statuscode = response.StatusCode;

                //WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
                //IAlert alert = driver.SwitchTo().Alert();
                //wait.Until(alert);
               
                //alert.SetAuthenticationCredentials("", "");
            }
        }

        [TestMethod]
        [Priority(1)]
        public void UploadImage()
        {
            //DesiredCapabilities capability = new DesiredCapabilities();
            //capability.SetCapability("IGNORE_ZOOM_SETTING", true);
            //capability.setCapability(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR, 1);
            //capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            //capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            //System.setProperty("webdriver.ie.driver", ieDriverPath);

            Driver.driver = new ChromeDriver();
            //Driver.driver = new InternetExplorerDriver();

            Google.NavigateToGoogle();

            Google.UploadImage();
        }

    }
}
