﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;

namespace DynamicDropdown
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void DynamicDropdown()
        {
            Driver.driver = new ChromeDriver();

            Utility utility = new Utility();
            utility.NavigateToAmazon();
            utility.NavigateToWatches();
        }

        [TestMethod]
        public void TryPrime()
        {
            Driver.driver = new ChromeDriver();
            Utility utility = new Utility();
            utility.NavigateToAmazon();
            utility.NavigateToPrime();
        }
    }
}
