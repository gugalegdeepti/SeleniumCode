﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicDropdown
{
    public class Utility
    {
        public void NavigateToAmazon()
        {
            Driver.driver.Navigate().GoToUrl("https://www.amazon.in/");
        }

        public void NavigateToWatches()
        {
            IWebElement shopByCategory = Driver.driver.FindElement(By.CssSelector("#nav-link-shopall"));
            Actions actions = new Actions(Driver.driver);
            actions.MoveToElement(shopByCategory).Build().Perform();
            IWebElement womensFashion = Driver.driver.FindElement(By.CssSelector("#nav-flyout-shopAll > div.nav-template.nav-flyout-content.nav-tpl-itemList > span:nth-child(10) > span"));
            actions.MoveToElement(womensFashion).Build().Perform();
            Driver.driver.FindElement(By.CssSelector("#nav-flyout-shopAll > div.nav-subcats > div:nth-child(9) > div.nav-column.nav-column-first > div:nth-child(4) > a:nth-child(1) > span")).Click();

        }

        public void NavigateToPrime()
        {
            IWebElement tryPrime = Driver.driver.FindElement(By.XPath("//*[@class='nav-sprite nav-logo-tagline nav-prime-try']"));
            Actions actions = new Actions(Driver.driver);
            actions.MoveToElement(tryPrime).Build().Perform();
            IWebElement getStarted = Driver.driver.FindElement(By.XPath("//*[@class='nav-npt-a']"));
            getStarted.Click();
        }
    }
}
