﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MicrosoftPOM.PageInventory;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;

namespace MicrosoftPOM
{
    [TestClass]
    public class UnitTest1 : BaseClass
    {
        [TestInitialize]
        public void Initialise()
        {
            NavigateToURL();
        }

        [TestMethod]
        public void CreateAccount()
        {
            //This test case cannot be continued as it requires OTP to verify user
            CreateAccount ca = new CreateAccount();
            ca.CreateNewAccount();
        }

        [TestMethod]
        public void SignInTest()
        {
            SignInPage signInPage = new SignInPage();
            Assert.AreEqual(signInPage.SignInTestMethod(), "gugaledeepti@yahoo.com");
        }

        [TestMethod]
        public void SurfacePageTest()
        {
            SurfacePage surfacePage = new SurfacePage();
            surfacePage.NavigateToOverview();
        }
        

        [TestCleanup]
        public void CleanUp()
        {
           // driver.Quit();
        }
    }
}
