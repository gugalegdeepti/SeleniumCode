﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftPOM.PageInventory
{
    public class SignInPage:BaseClass
    {
        public SignInPage()
        {
            PageFactory.InitElements(driver,this);
        }

        //BaseClass baseClass = new BaseClass();

        [FindsBy(How = How.CssSelector, Using = "#i0116")]
        private IWebElement EmailID;

        [FindsBy(How = How.CssSelector, Using = "#idSIButton9")]
        private IWebElement Next;

        [FindsBy(How = How.CssSelector, Using = "#signup")]
        private IWebElement CreateAccount;

        [FindsBy(How = How.CssSelector, Using = "#forgotUsername")]
        private IWebElement ForgotUsername;

        [FindsBy(How = How.CssSelector, Using = "#i0118")]
        private IWebElement Password;

        [FindsBy(How = How.CssSelector, Using = "#idA_PWD_ForgotPassword")]
        private IWebElement ForgotPassword;

        [FindsBy(How = How.CssSelector, Using = "#idChkBx_PWD_KMSI0Pwd")]
        private IWebElement KeepMeSignedIn;

        [FindsBy(How = How.Id, Using = "idSIButton9")]
        private IWebElement SignIn;

        [FindsBy(How = How.Id, Using = "mectrl_currentAccount_secondary")]
        private IWebElement CurrentAccountMailId;

        public SignInPage EnterEmailID(string emailId)
        {
            //baseClass.EnterText(EmailID, emailId);
            EmailID.SendKeys(emailId);
            return this;
            //return new SignInPage(driver);
        }

        public void CreateNewAccout()
        {
            CreateAccount.Click();
        }

        public void ForgotUserName()
        {
            ForgotUsername.Click();
        }

        public SignInPage ClickNext()
        {
            Next.Click();
            return this;
            //return new SignInPage(driver);
        }

        public SignInPage EnterPassword(string password)
        {
            //baseClass.EnterText(Password,password);
            Password.SendKeys(password);
            //return new SignInPage(driver);
            return this;
        }

        public void ClickSignIn()
        {
            SignIn.Click();
            //return new SignInPage(driver);
            //return this;
        }

        public String SignInTestMethod()
        {
            HomePage homePage = new HomePage();
            homePage.UserSignIn();

            //SignInPage signInPage = new SignInPage();
            //homePage.UserSignIn(driver).EnterEmailID("gugaledeepti@yahoo.com").ClickNext().EnterPassword("tejodeep123").ClickSignIn();
            EnterEmailID("gugaledeepti@yahoo.com").ClickNext().EnterPassword("tejodeep123").ClickSignIn();

            //Check if user is signed in
            homePage.UserSignIn();
            return CurrentAccountMailId.Text;
        }
    }
}
