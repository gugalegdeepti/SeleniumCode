﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace MicrosoftPOM.PageInventory
{
    public class HomePage:BaseClass
    {
        public HomePage()
        {
            PageFactory.InitElements(driver,this);
        }

        [FindsBy(How = How.CssSelector, Using = "#search")]
        private IWebElement Search;

        [FindsBy(How = How.CssSelector, Using = "#uhf-shopping-cart")]
        private IWebElement Cart;

        [FindsBy(How = How.Id, Using = "mectrl_main_trigger")]
        private IWebElement SignIn;

        [FindsBy(How = How.CssSelector, Using = "#shellmenu_0")]
        private IWebElement Office;

        [FindsBy(How=How.CssSelector, Using = "#shellmenu_1")]
        private IWebElement Windows;

        [FindsBy(How=How.CssSelector,Using = "#shellmenu_2")]
        private IWebElement Surface;

        [FindsBy(How=How.CssSelector, Using = "#shellmenu_3")]
        private IWebElement Xbox;

        [FindsBy(How=How.CssSelector, Using = "#l1_support")]
        private IWebElement Support;

        [FindsBy(How = How.Id, Using = "mectrl_currentAccount_secondary")]
        private IWebElement CurrentAccountSecondary;

        public void UserSignIn()
        {
            SignIn.Click();
            //return new SignInPage(driver);
        }

        public void SurfacePage()
        {
            ClickButton(Surface);
        }
    }
}
