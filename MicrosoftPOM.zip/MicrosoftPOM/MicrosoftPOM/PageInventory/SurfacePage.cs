﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftPOM.PageInventory
{
    public class SurfacePage:BaseClass
    {
        public SurfacePage()
        {
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "#c-shellmenu_37")]
        private IWebElement Computers;

        [FindsBy(How = How.CssSelector, Using = "#c-shellmenu_54")]
        private IWebElement Accessories;

        [FindsBy(How = How.CssSelector, Using = "#uhf-g-nav > ul > li:nth-child(2) > div > ul > li:nth-child(1) > button")]
        private IWebElement NewSurfacePro6;

        [FindsBy(How = How.CssSelector, Using = "#c-shellmenu_39")]
        private IWebElement Overview;

        [FindsBy(How = How.CssSelector, Using = "#coreui-banner-l30g7j1 > div > h2")]
        private IWebElement AMorePowerfulPro;

        [FindsBy(How = How.CssSelector, Using = "#in-page_generated_clone > div:nth-child(2) > a")]
        private IWebElement BuyNow;

        public SurfacePage ClickComputers()
        {
            ClickButton(Computers);
            return this;
        }

        public void ClickOverview()
        {
            HoverMouse(NewSurfacePro6);
            ClickButton(Overview);
            ScrollToElement(AMorePowerfulPro);
            ClickButton(BuyNow);
        }



        public void NavigateToOverview()
        {
            HomePage homePage = new HomePage();
            homePage.SurfacePage();
            ClickComputers().ClickOverview();
            
        }
    }
}
