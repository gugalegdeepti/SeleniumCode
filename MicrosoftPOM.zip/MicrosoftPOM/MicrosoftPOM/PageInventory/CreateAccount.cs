﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftPOM.PageInventory
{
    public class CreateAccount : BaseClass
    {
        public CreateAccount()
        {
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "#MemberName")]
        private IWebElement EmailID;

        [FindsBy(How = How.CssSelector, Using = "#phoneSwitch")]
        private IWebElement UsePhoneNumberInstead;

        [FindsBy(How = How.CssSelector, Using = "#phoneSwitch")]
        private IWebElement GetANewEmailAddress;

        [FindsBy(How = How.Id, Using = "iSignupAction")]
        private IWebElement Next;

        [FindsBy(How = How.CssSelector, Using = "#PasswordInput")]
        private IWebElement Password;

        [FindsBy(How = How.CssSelector, Using = "#FirstName")]
        private IWebElement FirstName;

        [FindsBy(How = How.CssSelector, Using = "#LastName")]
        private IWebElement LastName;

        [FindsBy(How = How.CssSelector, Using = "#BirthDay")]
        private IWebElement BirthDay;

        [FindsBy(How = How.CssSelector, Using = "#BirthMonth")]
        private IWebElement BirthMonth;

        [FindsBy(How = How.CssSelector, Using = "#BirthYear")]
        private IWebElement BirthYear;

        [FindsBy(How = How.CssSelector, Using = "#Country")]
        private IWebElement Country;

        public CreateAccount EnterEmailId(string emailId)
        {
            EnterText(EmailID, emailId);
            return this;
        }

        public CreateAccount EnterPassword(string password)
        {
            EnterText(Password, password);
            return this;
        }

        public CreateAccount ClickNext()
        {
            ClickButton(Next);
            return this;
        }

        public CreateAccount EnterFirstName(string firstName)
        {
            EnterText(FirstName, firstName);
            return this;
        }

        public CreateAccount EnterLastName(string lastName)
        {
            EnterText(LastName, lastName);
            return this;
        }

        public CreateAccount SelectDay(string birthDay)
        {
            SelectFromDropDown(BirthDay, birthDay);
            return this;
        }

        public CreateAccount SelectMonth(string birthMonth)
        {
            SelectFromDropDown(BirthMonth, birthMonth);
            return this;
        }

        public CreateAccount SelectYear(string birthYear)
        {
            SelectFromDropDown(BirthYear, birthYear);
            return this;
        }

        public CreateAccount SelectCountry(string country)
        {
            SelectFromDropDown(Country, country);
            return this;
        }

        public void CreateNewAccount()
        {
            HomePage homepage = new HomePage();
            homepage.UserSignIn();

            SignInPage signInPage = new SignInPage();
            signInPage.CreateNewAccout();

            EnterEmailId("dghi331@gmail.com").ClickNext().EnterPassword("tejodeep123").ClickNext()
                .EnterFirstName("testFirstName").EnterLastName("testLastName").ClickNext()
                .SelectCountry("IN").SelectDay("23").SelectMonth("6").SelectYear("1993").ClickNext();

            
        }
    }
}
