﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftPOM.PageInventory
{
    public class SignInPage:BaseClass
    {
        public SignInPage()
        {
            PageFactory.InitElements(driver, this);
        }



        [FindsBy(How = How.CssSelector, Using = "#ap_email")]
        private IWebElement EmailId;

        [FindsBy(How=How.CssSelector, Using = "#continue")]
        private IWebElement Continue;

        [FindsBy(How = How.CssSelector, Using = "#ap_password")]
        private IWebElement Password;

        [FindsBy(How = How.CssSelector, Using = "#signInSubmit")]
        private IWebElement LogIn;

        public SignInPage EnterEmailId(string emailId)
        {
            EnterText(EmailId, emailId);
            return this;
        }

        public SignInPage EnterContinue()
        {
            ClickButton(Continue);
            return this;
        }

        public SignInPage EnterPassword(string password)
        {
            EnterText(Password, password);
            return this;
        }

        public SignInPage EnterLogIn()
        {
            ClickButton(LogIn);
            return this;
        }

        public string UserSignIn()
        {
            HomePage homePage = new HomePage();
            homePage.SignIn();
            EnterEmailId("gugaledeepti@gmail.com").EnterContinue().EnterPassword("tejodeep123").EnterLogIn();
            return homePage.GetHelloText();
        }
    }
}
