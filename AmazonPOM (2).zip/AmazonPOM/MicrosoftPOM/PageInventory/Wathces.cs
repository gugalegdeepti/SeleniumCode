﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftPOM.PageInventory
{
    public class Watches:BaseClass
    {
        public Watches()
        {
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "#dealImage > div > div > div.a-row.layer.backGround")]
        private IWebElement FossilAnalogWatch;

        public void ClickFossilAnalogWatch()
        {
            //ScrollToElement(FossilAnalogWatch);
            //ClickButton(FossilAnalogWatch);
            FossilAnalogWatch.Click();
        }
    }
}
