﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace MicrosoftPOM.PageInventory
{
    public class HomePage:BaseClass
    {
        public HomePage()
        {
            PageFactory.InitElements(driver,this);
        }

        [FindsBy(How = How.CssSelector, Using = "#nav-link-yourAccount > span.nav-line-1")]
        private IWebElement Hello;

        [FindsBy(How = How.CssSelector, Using = "#nav-flyout-ya-signin > a > span")]
        private IWebElement SignInButton;

        [FindsBy(How = How.CssSelector, Using = "#nav-link-shopall")]
        private IWebElement ShopByCategory;

        [FindsBy(How = How.CssSelector, Using = "#nav-flyout-shopAll > div.nav-template.nav-flyout-content.nav-tpl-itemList > span:nth-child(10) > span")]
        private IWebElement WomensFashion;

        [FindsBy(How = How.CssSelector, Using = "#nav-flyout-shopAll > div.nav-subcats > div:nth-child(9) > div.nav-column.nav-column-first > div:nth-child(4) > a:nth-child(1) > span")]
        private IWebElement Watches;

        public void SignIn()
        {
            HoverMouse(Hello);
            ClickButton(SignInButton);
        }

        public string GetHelloText()
        {
            return GetText(Hello);
        }

        public HomePage GoToWatches()
        {
            HoverMouse(ShopByCategory);
            HoverMouse(WomensFashion);
            ClickButton(Watches);
            return this;
        }
    }
}
