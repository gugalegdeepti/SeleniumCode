﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftPOM.PageInventory
{
    public class FossilWatchPage:BaseClass
    {
        public FossilWatchPage()
        {
            PageFactory.InitElements(driver,this);
        }

        [FindsBy(How = How.CssSelector, Using = "#add-to-cart-button")]
        private IWebElement AddToCart;

        public void ClickAddToCart()
        {
            ClickButton(AddToCart);
        }

        public void AddProductToCart()
        {
            HomePage homePage = new HomePage();
            homePage.GoToWatches();
            Watches watches = new Watches();
            watches.ClickFossilAnalogWatch();
            driver.FindElement(By.XPath("//*[@id='result_0']/div/div[2]/div/a/img")).Click();
            string currentWindow = driver.CurrentWindowHandle;
            List<string> handles = driver.WindowHandles.ToList();
            foreach (string window in handles)
            {
                if (window != currentWindow)
                {
                    driver.SwitchTo().Window(window);
                    ClickAddToCart();
                    driver.FindElement(By.XPath("//*[@id='hlb - view - cart - announce']")).Click();
                }
            }
            
        }
    }
}
