﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MicrosoftPOM.PageInventory;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;

namespace MicrosoftPOM
{
    [TestClass]
    public class UnitTest1 : BaseClass
    {
        [TestInitialize]
        public void Initialise()
        {
            NavigateToURL();
        }

        [TestMethod]
        public void SignInTest()
        {
            SignInPage signInPage = new SignInPage();
            Assert.AreEqual(signInPage.UserSignIn(), "Hello, Deepti");
        }

        [TestMethod]
        public void AddProductToCart()
        {
            FossilWatchPage fWPage = new FossilWatchPage();
            fWPage.AddProductToCart();
        }

        [TestMethod]
        public void TestMethod()
        {
            driver.Navigate().GoToUrl("https://www.amazon.in/s/ref=gbph_img_m10_188e_a39afda0?fst=as%3Aoff&rh=n%3A1350387031%2Cn%3A%211499791031%2Cn%3A%211499793031%2Cn%3A15594672031%2Cp_6%3AAT95IG9ONZD7S&bbn=15594672031&ie=UTF8&qid=1548256448&rnid=1318474031&smid=AT95IG9ONZD7S&pf_rd_p=1c3411dd-ff1a-4732-a065-f500968e188e&pf_rd_s=merchandised-search-10&pf_rd_t=101&pf_rd_i=2563505031&pf_rd_m=A1VBAL9TL5WCBF&pf_rd_r=K44Z9ES3FWXY3E34YFW2");
            IWebElement element = driver.FindElement(By.XPath("//*[@id='result_0']/div/div[2]/div/a/img"));
            element.Click();
            driver.FindElement(By.XPath("//*[@id='hlb - view - cart - announce']")).Click();
        }

        [TestCleanup]
        public void CleanUp()
        {
           // driver.Quit();
        }
    }
}
