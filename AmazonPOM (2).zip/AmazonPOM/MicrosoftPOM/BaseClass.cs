﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace MicrosoftPOM
{
    public class BaseClass
    {
        public static IWebDriver driver;

        public void ClearCookies()
        {
            driver.Manage().Cookies.DeleteAllCookies();
        }

        //Navigate to URL
        public void NavigateToURL()
        {
            driver = new ChromeDriver();
            ClearCookies();
            driver.Navigate().GoToUrl("https://www.amazon.in");
        }

        //Get URL
        public string GetURL()
        {
            return driver.Url;
        }
        
        //Explicit Wait
        public void WaitToClick(IWebElement element)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(element));
        }

        //Pageload wait
        public void WaitForPageLoad()
        {
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
        }

        //Switch to alert
        public void SwitchToAlert()
        {
            IAlert alert = driver.SwitchTo().Alert();
            alert.Accept();
        }

        //Enter text
        public void EnterText(IWebElement element, string text)
        {
            element.Clear();
            element.SendKeys(text);
        }

        //Get text
        public string GetText(IWebElement element)
        {
            return element.Text;
        }

        //Click a button
        public void ClickButton(IWebElement element)
        {
            element.Click();
        }

        public void SelectFromDropDown(IWebElement element, string value)
        {
            SelectElement select = new SelectElement(element);
            select.SelectByValue(value);
        }

        public void HoverMouse(IWebElement element)
        {
            Actions actions = new Actions(driver);
            actions.MoveToElement(element).Build().Perform();
        }

        public void ScrollToElement(IWebElement element)
        {
            ((IJavaScriptExecutor)driver).ExecuteScript("argument[0].ScrollIntoView()", element);
        }

        public void GetScreenshot()
        {
            Screenshot screen = ((ITakesScreenshot)driver).GetScreenshot();
        }
    }
}
