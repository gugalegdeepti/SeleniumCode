﻿namespace FetchDataFromExcel
{
    internal class InitializeDriver
    {
        internal object driver;
    }
}