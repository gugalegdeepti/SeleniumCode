﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using System.IO;
using NPOI.XSSF.UserModel;
using System.Collections.Generic;
using System.Linq;

namespace FetchDataFromExcel
{
    [TestClass]
    public class UnitTest1
    {
        
        //private readonly object MessageBox;

        [TestMethod]
        public void ReadExcelData()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();

            driver.Navigate().GoToUrl("https://google.com");

            XSSFWorkbook hssfwb;
            using (FileStream file = new FileStream(@"D:\\Selenium\test.xlsx",FileMode.Open,FileAccess.Read))
            {
                hssfwb = new XSSFWorkbook(file);
            }

            ISheet sheet = hssfwb.GetSheet("SearchData");
            string testdata = null;
            for (int row = 0; row <= sheet.LastRowNum; row++)
            {
                if (sheet.GetRow(row) != null)
                {
                    //MessageBox.Show(string.Format("Row {0} = {1}", row, sheet.GetRow(row).GetCell(0).StringCellValue));
                    testdata = sheet.GetRow(row).GetCell(0).StringCellValue;
                    
                }
                IWebElement ele = driver.FindElement(By.CssSelector("#tsf > div:nth-child(2) > div > div.RNNXgb > div > div.a4bIc > input"));
                ele.SendKeys(testdata);
            }

           driver.Quit();
        }

        [TestMethod]
        public void NavigateToUrl()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();

            XSSFWorkbook xssfwb;

            using (FileStream file = new FileStream(@"D:\Selenium\test.xlsx", FileMode.Open, FileAccess.Read))
            {
                xssfwb = new XSSFWorkbook(file);
            }
            ISheet sheet = xssfwb.GetSheet("UrlList");
            string value = null;

            for (int row = 0; row < sheet.LastRowNum; row++)
            {
                ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
            }
            IList<string> lstWindow = driver.WindowHandles.ToList();

            //foreach (var handle in lstWindow, int row in sheet.LastRowNum)
            //{
            //    driver.SwitchTo().Window(handle);

            //}

            for (int row = 0, i = 0; i < lstWindow.Count & row <= sheet.LastRowNum; i++, row++)
            {
                value = sheet.GetRow(row).GetCell(0).StringCellValue;
                //driver.Navigate().GoToUrl(value);
               // ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
                driver.SwitchTo().Window(lstWindow[i]);
                driver.Navigate().GoToUrl(value);
            }
            driver.Quit();
        }

        [TestMethod]
        public void WriteToExcel()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();

            XSSFWorkbook xssfwb = null;
            using (FileStream file = new FileStream(@"D:\Selenium\test.xlsx", FileMode.Open, FileAccess.ReadWrite))
            {
                xssfwb = new XSSFWorkbook(file);
            }
            ISheet sheet = xssfwb.GetSheet("WriteData");
            sheet.GetRow(0).GetCell(0).SetCellValue("Sample");
        }
    }
}
