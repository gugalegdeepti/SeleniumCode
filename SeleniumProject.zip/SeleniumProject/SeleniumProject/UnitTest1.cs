﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SeleniumProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //User login
            HomePage homePage = new HomePage();
            homePage.UserLogin("mercury", "mercury");

            //Enter all fields on Reservation page, enter continue button
            //and check if user is navigated to next page
            //Verify the page title of new page
            FlightFinder flightfinder = new FlightFinder();
            Assert.AreEqual(flightfinder.EnterFlightDetails(), "Select a Flight: Mercury Tours");
            
        }
    }
}
