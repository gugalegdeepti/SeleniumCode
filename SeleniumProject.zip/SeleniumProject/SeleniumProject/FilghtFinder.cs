﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace SeleniumProject
{
    public class FlightFinder : BaseClass
    {
        public FlightFinder()
        {
            PageFactory.InitElements(driver,this);
        }

        [FindsBy(How = How.CssSelector, Using = "body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(5) > td > form > table > tbody > tr:nth-child(2) > td:nth-child(2) > b > font > input[type='radio']:nth-child(1)")]
        private IWebElement Roundtrip;

        [FindsBy(How = How.CssSelector, Using = "body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(5) > td > form > table > tbody > tr:nth-child(2) > td:nth-child(2) > b > font > input[type='radio']:nth-child(2)")]
        private IWebElement OneWay;

        [FindsBy(How = How.Name, Using = "passCount")]
        private IWebElement Passenger;

        [FindsBy(How = How.Name, Using = "fromPort")]
        private IWebElement FromPort;

        [FindsBy(How = How.Name, Using = "fromMonth")]
        private IWebElement FromMonth;

        [FindsBy(How = How.Name, Using = "fromDay")]
        private IWebElement FromDay;

        [FindsBy(How = How.Name, Using = "toPort")]
        private IWebElement ArrivingIn;

        [FindsBy(How = How.Name, Using = "toMonth")]
        private IWebElement ToMonth;

        [FindsBy(How = How.Name, Using = "toDay")]
        private IWebElement ToDay;

        [FindsBy(How = How.XPath, Using = "//input[@name='servClass' and @value='Business']")]
        private IWebElement BusinessClass;

        [FindsBy(How = How.Name, Using = "airline")]
        private IWebElement Airline;

        [FindsBy(How = How.Name, Using = "findFlights")]
        private IWebElement ContinueButton;

        public string EnterFlightDetails()
        {
            ButtonClick(Roundtrip);
            SelectDropdown(Passenger, "SelectByValue", "2");
            SelectDropdown(FromPort, "SelectByValue", "Frankfurt");
            SelectDropdown(FromMonth, "SelectByText", "January");
            SelectDropdown(FromDay, "SelectByText", "24");
            SelectDropdown(ArrivingIn, "SelectByValue", "London");
            SelectDropdown(ToMonth, "SelectByValue", "3");
            SelectDropdown(ToDay, "SelectByValue", "3");
            ButtonClick(BusinessClass);
            SelectDropdown(Airline, "SelectByText", "Pangea Airlines");
            ButtonClick(ContinueButton);
            return(driver.Title);
            //Select a Flight: Mercury Tours
        }
    }
}
