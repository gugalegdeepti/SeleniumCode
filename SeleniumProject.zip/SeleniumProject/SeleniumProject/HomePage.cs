﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.PageObjects;

namespace SeleniumProject
{
    public class HomePage : BaseClass
    {
        public HomePage()
        {
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td:nth-child(3) > form > table > tbody > tr:nth-child(4) > td > table > tbody > tr:nth-child(2) > td:nth-child(2) > input[type='text']")]
        private IWebElement Username;


        //[FindsBy(How = How.CSSSelector, Using = "body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td:nth-child(3) > form > table > tbody > tr:nth-child(4) > td > table > tbody > tr:nth-child(3) > td:nth-child(2) > input[type='password']")]

        [FindsBy(How = How.XPath, Using = "//input[@type='password']")]
        private IWebElement Password;

        [FindsBy(How = How.Name, Using = "login")]
        private IWebElement Signin;

        public void UserLogin(string username, string password)
        {
            LaunchDriver();
            Navigate();
            EnterText(Username, username);
            EnterText(Password,password);
            ButtonClick(Signin);
        }
    }
}
