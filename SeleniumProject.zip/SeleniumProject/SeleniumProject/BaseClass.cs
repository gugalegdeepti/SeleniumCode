﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace SeleniumProject
{
    public class BaseClass
    {
        public static IWebDriver driver = new ChromeDriver();
        public void LaunchDriver()
        {
            //driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();
        }

        public void Navigate()
        {
            driver.Navigate().GoToUrl("http://newtours.demoaut.com/");
        }

        public void EnterText(IWebElement element, string value)
        {
            element.SendKeys(value);
        }

        public void ButtonClick(IWebElement element)
        {
            element.Click();
        }

        public void SelectDropdown(IWebElement element, string selectType, string value)
        {
            SelectElement oselect = new SelectElement(element);
            if (selectType == "SelectByText")
            {
                oselect.SelectByText(value);
            }
            else if (selectType == "SelectByValue")
            {
                oselect.SelectByValue(value);
            }
            //else if (selectType == "SelectByIndex")
            //{
            //    oselect.SelectByIndex(value);
            
        }
    }
}
