﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace PhntomJS
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--headless");
            IWebDriver driver = new ChromeDriver(options);
            string[] pageSource;

            string sitemapURL = @"http://testing.todvachev.com/sitemap-posttype-post.xml";

            driver.Navigate().GoToUrl(sitemapURL);

            pageSource = driver.PageSource.Split(' ');
        }
    }
}
