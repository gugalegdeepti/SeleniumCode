﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;

namespace WindowHandles.cs
{
    [TestClass]
    public class Window
    {
        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            string url = "http://testing.todvachev.com/tabs-and-windows/new-tab/";

            driver.Navigate().GoToUrl(url);

            string getUrl = driver.Url;

            int pageUrlLength = driver.Url.Length;

            IWebElement newTab = driver.FindElement(By.CssSelector("#post-182 > div > p:nth-child(1) > a:nth-child(1)"));
            IWebElement newWindow = driver.FindElement(By.CssSelector("#post-182 > div > p:nth-child(1) > a:nth-child(3)"));

            newTab.Click();

            Thread.Sleep(3000);

            List<string> handles = new List<string>();

            ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
            
            handles = driver.WindowHandles.ToList();

            driver.SwitchTo().Window(handles[0]);

            driver.FindElement(By.Name("username")).SendKeys("selenium");
            //Actions actions = new Actions();
            Thread.Sleep(3000);

            for (int i = 0; i < handles.Count; i++)
            {
                if (i != 0)
                {
                    driver.SwitchTo().Window(handles[i]);
                    driver.Close();
                }
            }

            Thread.Sleep(3000);
        }
    }
}
