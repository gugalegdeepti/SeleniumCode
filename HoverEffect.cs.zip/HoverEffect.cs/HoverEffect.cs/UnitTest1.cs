﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;

namespace HoverEffect.cs
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void HoverElement()
        {
            IWebDriver driver = new ChromeDriver();
            string url = "http://testing.todorvachev.com/draganddrop/draganddrop.html";
            driver.Navigate().GoToUrl(url);

            string[] elementIDs = { "Drag1", "Drag2", "Drag3", "Drag4", "Drag5" };

            IWebElement[] elements =
            {
                driver.FindElement(By.Id(elementIDs[0])),
                driver.FindElement(By.Id(elementIDs[1])),
                driver.FindElement(By.Id(elementIDs[2])),
                driver.FindElement(By.Id(elementIDs[3])),
                driver.FindElement(By.Id(elementIDs[4])),
            };

            Actions actions = new Actions(driver);

            //Mouse Hover
            actions.MoveToElement(elements[0]).Build().Perform();

            //Drag and Drop
            actions.ClickAndHold(elements[0]).MoveToElement(elements[1]).MoveByOffset(0, 20).Release().Build().Perform();

        }


        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            string url = "http://testing.todorvachev.com/draganddrop/draganddrop.html";
            driver.Navigate().GoToUrl(url);
            string[] elementIDs =
            {
                "Drag1", "Drag2", "Drag3", "Drag4", "Drag5"
            };

            IWebElement[] elements =
            {
                driver.FindElement(By.Id(elementIDs[0])),
                driver.FindElement(By.Id(elementIDs[1])),
                driver.FindElement(By.Id(elementIDs[2])),
                driver.FindElement(By.Id(elementIDs[3])),
                driver.FindElement(By.Id(elementIDs[4])),
            };


            

            Actions actions = new Actions(driver);
            actions.MoveToElement(elements[0]).Build().Perform();
                
        }
    }
}
