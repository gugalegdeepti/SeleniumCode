﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HDFCTable
{
    public class AccountStatement
    {
        public AccountStatement()
        {
            PageFactory.InitElements(Driver.driver, this);
        }

        [FindsBy(How=How.XPath, Using = "//*[@id='hideradio']//*[@class='radio']")]
        public IWebElement SelectPeriodRadioButton { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[@id='casaCal']//*[@class='ui-button-icon-primary ui-icon ui-icon-calendar']")]
        [FindsBy(How = How.XPath, Using = "//*[@id='frmDatePicker']")]
        public IWebElement FromDate { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='toDatePicker']")]
        public IWebElement ToDate { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='viewBtn']")]
        public IWebElement ViewButton { get; set; }

        public void SelectAccountType()
        {
            SelectElement oselect = new SelectElement(Driver.driver.FindElement(By.Name("selAccttype")));
            oselect.SelectByText("Saving And Current Accounts");
        }

        public void SelectAccountNumber()
        {
            SelectElement oselect = new SelectElement(Driver.driver.FindElement(By.Name("selAcct")));
            oselect.SelectByValue("50100115401545  ");
        }
    }
}
