﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using System.Collections;
using System.Collections.Generic;

namespace HDFCTable
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            LoginPage lp = new LoginPage();
            //string x = Driver.driver.Url("    ");
             Driver.driver.Navigate().GoToUrl("https://netbanking.hdfcbank.com/netbanking/");
            //string x = Driver.driver.Url;
            Thread.Sleep(1000);
            Driver.driver.Manage().Window.Maximize();
            Driver.driver.SwitchTo().Frame("login_page");
            Thread.Sleep(1000);
            //Driver.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20000);

            if (Driver.driver.FindElement(By.XPath("//span[@class='pwd_field']/input[@class='input_password']")).Displayed)
            {
                lp.LoginField.SendKeys("63793837");
            }
            lp.ContinueButton.Click();
            lp.Password.SendKeys("!Tejodeep123!");
            lp.SecureCheckbox.Click();
            lp.LogInButton.Click();

            //If OTP page is introduced
           // lp.MobNoCheckbox.Click();
            //lp.Continue2.Click();
           // Thread.Sleep(60000);

            //lp.Continue2.Click();

            //Home Page Operations
            HomePage hp = new HomePage();

            Driver.driver.SwitchTo().Frame("left_menu");

            hp.FinancialSummary.Click();
            Driver.driver.SwitchTo().DefaultContent();
            Thread.Sleep(2000);
            Driver.driver.SwitchTo().Frame("main_part");
            hp.SavingsAcc.Click();
            hp.View.Click();
            hp.SelectPeriod.Click();
            Thread.Sleep(5000);

            AccountStatement accstat = new AccountStatement();
            accstat.SelectAccountType();
            accstat.SelectAccountNumber();
            accstat.SelectPeriodRadioButton.Click();
            accstat.FromDate.SendKeys("01/11/2018");
            accstat.ToDate.SendKeys("13/12/2018");
            accstat.ViewButton.Click();

            //Find pages
            IList<IWebElement> Pages = Driver.driver.FindElements(By.XPath("//*[@name='l_dummy']"));
            //foreach (IWebElement page in Pages)
            for(int i=1; i<= Pages.Count; i++)
            {
                string pageID = i.ToString();
                //traverse table values
                IList<IWebElement> headers = Driver.driver.FindElements(By.XPath("//table[@class='datatable'][@id=" + i + "]/tbody/tr/th"));
                int rowCount = Driver.driver.FindElements(By.XPath("//table[@class='datatable'][@id="+i+"]/tbody/tr/td[1]")).Count;
                //IWebElement row = Driver.driver.FindElement();
                IList<IWebElement> tableRows = Driver.driver.FindElements(By.XPath("//table[@class='datatable'][@id=" + i + "]/tbody/tr"));
                IList<IWebElement> rowTD = null;
                bool flag = false;
                string tdValue = null;
                foreach (IWebElement row in tableRows)
                {
                    rowTD = row.FindElements(By.TagName("td"));
                    foreach (IWebElement td in rowTD)
                    {
                        tdValue = td.GetAttribute("value");
                        tdValue = td.Text;
                        if (tdValue == "006239756237 " || tdValue == "006239756237")
                        {
                            flag = true;
                            break;
                        }
                        if (flag == true)
                            break;
                    }
                    if (flag == true)
                        break;
                }
                Driver.driver.FindElement(By.XPath("//*[@id='l_next']")).Click();
            }

                Thread.Sleep(2000);
            //Driver.driver.Close();

        }
    }
}
