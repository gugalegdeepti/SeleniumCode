﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace HDFCTable
{
    public class LoginPage
    {
        public LoginPage()
        {
            PageFactory.InitElements(Driver.driver, this);
        }

        [FindsBy(How=How.XPath, Using = "//span[@class='pwd_field']/input[@class='input_password']")]
        public IWebElement LoginField { get; set; }

        [FindsBy(How=How.CssSelector, Using = "body > form > table:nth-child(17) > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(1) > td:nth-child(1) > table > tbody > tr:nth-child(3) > td:nth-child(2) > table > tbody > tr:nth-child(6) > td:nth-child(2) > a > img")]
        public IWebElement ContinueButton { get; set; }

        [FindsBy(How=How.CssSelector, Using = "body > form > table:nth-child(26) > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(1) > td:nth-child(1) > table > tbody > tr:nth-child(3) > td:nth-child(2) > table > tbody > tr:nth-child(4) > td:nth-child(2) > span > input")]
        public IWebElement Password { get; set; }

        [FindsBy(How=How.CssSelector, Using = "#chkrsastu")]
        public IWebElement SecureCheckbox { get; set; }

        [FindsBy(How=How.CssSelector, Using = "body > form > table:nth-child(26) > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(1) > td:nth-child(1) > table > tbody > tr:nth-child(3) > td:nth-child(2) > table > tbody > tr:nth-child(6) > td > table > tbody > tr:nth-child(9) > td > a")]
        public IWebElement LogInButton { get; set; }

        [FindsBy(How=How.XPath, Using = "//input[@name='fldMobile']")]
        public IWebElement MobNoCheckbox { get; set; }

        [FindsBy(How=How.XPath, Using = "//a[@target='_self']")]
        public IWebElement Continue2 { get; set; }
    }
}
