﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Microsoft.CSharp;
using excel = Microsoft.Office.Interop.Excel;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace ReadExcel
{
    [TestClass]
    public class UnitTest1
    {
        IWebDriver driver = new ChromeDriver();
        [TestMethod]
        public void ReadExcel()
        {
            excel.Application xlapp = new excel.Application();
            //Open Workbook
            excel.Workbook xlworkbook = xlapp.Workbooks.Open(@"C:\Users\M1034355\Desktop\Urls.xlsx");
            //Open Sheet
            excel._Worksheet xlworksheet = xlworkbook.Sheets[1];

            excel.Range xlrange = xlworksheet.UsedRange;
            string website = null;
            //Actions actions = new Actions(driver);
            for (int i = 1; i <= 3; i++)
            {
                website = xlrange.Cells[i][1].value2;
                driver.Navigate().GoToUrl(website);
                //((IJavaScriptExecutor)driver).ExecuteScript("window.open();");
                //driver.SwitchTo().Window();
                //actions.SendKeys(Keys.Control+"t").Build().Perform();
                //actions.KeyDown(Keys.Control).SendKeys("t").Build().Perform();
                //Thread.Sleep(3000);
                //actions.KeyUp(Keys.Control).Build().Perform();
            }
        }
    }
}
