﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace Assignment
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Assignment1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://newtours.demoaut.com/");
            driver.FindElement(By.Name("userName")).SendKeys("mercury");
            //username.SendKeys("Deepti");
            IWebElement password = driver.FindElement(By.Name("password"));
            password.SendKeys("mercury");
            driver.FindElement(By.CssSelector("body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td:nth-child(3) > form > table > tbody > tr:nth-child(4) > td > table > tbody > tr:nth-child(4) > td:nth-child(2) > div > input[type='image']")).Click();
            driver.FindElement(By.CssSelector("body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td:nth-child(1) > a")).Click();
            //driver.FindElement(By.CssSelector("body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td:nth-child(1)"));
            driver.Close();
        }

        [TestMethod]
        public void Assignment2()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://demosite.center/wordpress/wp-login.php");
            driver.FindElement(By.XPath("//input[@name='log' and @id='user_login']")).SendKeys("mercury");
            //username.SendKeys("Deepti");
            IWebElement password = driver.FindElement(By.XPath("//input[@name='pwd' and @id='user_pass']"));
            password.SendKeys("mercury");
            driver.FindElement(By.Id("wp-submit")).Click();
            
            driver.Close();
        }

        [TestMethod]
        public void Assignment3()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://uitestpractice.com");
            //Click Form
            driver.FindElement(By.XPath("//*[@class= 'nav navbar-nav']/li[3]")).Click();
            //driver.FindElement(By.CssSelector("body > div.navbar.navbar-inverse.navbar-fixed-top > div > div.navbar-collapse.collapse > ul > li:nth-child(3) > a")).Click();
            //username.SendKeys("Deepti");
            //First name
            IWebElement firstNameword = driver.FindElement(By.XPath("//input[@id='firstname']"));
            firstNameword.SendKeys("mercury");
            //Last name
            IWebElement lastName = driver.FindElement(By.XPath("//input[@id='lastname']"));
            lastName.SendKeys("mercury");
            //Marietal Status and Hobby
            driver.FindElement(By.CssSelector("body > div.container.body-content > div:nth-child(1) > div > form > div:nth-child(3) > label:nth-child(3) > input[type='radio']")).Click();
            driver.FindElement(By.CssSelector("body > div.container.body-content > div:nth-child(1) > div > form > div:nth-child(5) > label:nth-child(2) > input[type='checkbox']")).Click();
            //Country
            SelectElement oselect = new SelectElement(driver.FindElement(By.Id("sel1")));
            oselect.SelectByText("Afghanistan");

            driver.FindElement(By.Id("datepicker")).SendKeys("02/17/1988");
            driver.FindElement(By.Id("phonenumber")).SendKeys("749029029");
            driver.FindElement(By.XPath("//*[@id='username']")).SendKeys("mercury");
            driver.FindElement(By.XPath("//*[@id='email']")).SendKeys("abc@gmail.com");
            driver.FindElement(By.Id("comment")).SendKeys("abc");
            string aboutyourself = driver.FindElement(By.XPath("//*[@id='comment']")).GetAttribute("value");
            driver.FindElement(By.XPath("//input[@id='pwd']")).SendKeys("mercury");
            driver.FindElement(By.XPath("//button[text()='Submit']")).Click();
            driver.Close();
        }
    }
}
