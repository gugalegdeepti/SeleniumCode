﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Assignment1
{
    [TestClass]
    public class Assignment1
    {
        [TestMethod]
        public void Assignment1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://newtours.demoaut.com/");
            driver.FindElement(By.Name("userName")).SendKeys("mercury");
            //username.SendKeys("Deepti");
            IWebElement password = driver.FindElement(By.Name("password"));
            password.SendKeys("mercury");
            driver.FindElement(By.CssSelector("body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(4) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td:nth-child(3) > form > table > tbody > tr:nth-child(4) > td > table > tbody > tr:nth-child(4) > td:nth-child(2) > div > input[type='image']")).Click();
            driver.FindElement(By.CssSelector("body > div > table > tbody > tr > td:nth-child(2) > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td:nth-child(1) > a")).Click();
            driver.Close();
        }
    }
}
