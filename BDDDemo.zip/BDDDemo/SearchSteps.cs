﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace BDDDemo
{
    [Binding]
    public class SearchSteps
    {
        IWebDriver driver;
        IWebElement searchbox;
        [Given(@"Launch Chrome browser")]
        public void GivenLaunchChromeBrowser()
        {
            driver = new ChromeDriver();
        }
        
        [Given(@"Navigate to Google")]
        public void GivenNavigateToGoogle()
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMinutes(1);
            driver.Navigate().GoToUrl("https://www.google.com/");
        }
        
        [When(@"Click on Search textbox")]
        public void WhenClickOnSearchTextbox()
        {
            searchbox = driver.FindElement(By.CssSelector("#tsf > div:nth-child(2) > div > div.RNNXgb > div > div.a4bIc > input"));
        }
        
        [When(@"Enter Testing")]
        public void WhenEnterTesting()
        {
            searchbox.SendKeys("Testing");
        }
        
        [When(@"Click on Search Button")]
        public void WhenClickOnSearchButton()
        {
            driver.FindElement(By.CssSelector("#tsf > div:nth-child(2) > div > div.FPdoLc.VlcLAe > center > input[type='submit']:nth-child(1)")).Click();
        }
        
        [Then(@"Result should be visible and browser should close")]
        public void ThenResultShouldBeVisibleAndBrowserShouldClose()
        {
            driver.Quit();
        }
    }
}
