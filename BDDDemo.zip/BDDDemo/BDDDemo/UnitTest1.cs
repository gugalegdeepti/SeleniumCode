﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace BDDDemo
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Launch Browser
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMinutes(1);
            //Navigate to URL
            driver.Navigate().GoToUrl("https://www.google.com/");
            //Click on search textbox
            IWebElement searchbox = driver.FindElement(By.CssSelector("#tsf > div:nth-child(2) > div > div.RNNXgb > div > div.a4bIc > input"));

            //Enter testing
            searchbox.SendKeys("Testing");

            //Click on search button
            driver.FindElement(By.CssSelector("#tsf > div:nth-child(2) > div > div.FPdoLc.VlcLAe > center > input[type='submit']:nth-child(1)")).Click();

            //Close window
            driver.Quit();
        }
    }
}
