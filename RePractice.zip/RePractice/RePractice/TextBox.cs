﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace RePractice
{
    [TestClass]
    public class SpecialElements
    {
        [TestMethod]
        public void CheckTextbox()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://login.salesforce.com/");
            IWebElement element = driver.FindElement(By.Name("username"));
            element.Clear();
            element.SendKeys("Deepti");
            string value = element.GetAttribute("value");
            string value1 = element.Text;
        }

    }
}
