﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace RePractice
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://login.salesforce.com/");
            IWebElement element = driver.FindElement(By.Id("logo"));
            if (element.Displayed)
            {
                Console.WriteLine("Element is displayed");
            }
            else
            {
                Console.WriteLine("Element is not displayed");
            }
        }
    }
}
